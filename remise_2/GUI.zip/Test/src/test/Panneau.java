package test;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;
/**
 *
 * @author Simon
 */
public class Panneau extends JPanel{
    public Panneau(){
        
    }
    public void paintComponent(Graphics g){
        setBackground(Color.ORANGE);
        int x1 = this.getWidth()/4;
        int y1 = this.getHeight()/4;                      
        g.fillOval(x1, y1, this.getWidth()/2, this.getHeight()/2);
        setBackground(Color.ORANGE);
        
        
    }
}
